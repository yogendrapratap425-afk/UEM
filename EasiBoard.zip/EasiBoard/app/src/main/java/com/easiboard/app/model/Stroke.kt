package com.easiboard.app.model

import androidx.compose.ui.geometry.Offset
import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * A single captured sample from the input device (finger or stylus) during a stroke.
 * [pressure] comes from the stylus if available (0f..1f), otherwise is synthesized
 * from drawing speed in [com.easiboard.app.engine.SoftPenPhysics].
 * [timestampNanos] is used to compute instantaneous velocity between consecutive points,
 * which is what drives the "soft pen" thickness modulation.
 */
@Serializable
data class StrokePoint(
    val x: Float,
    val y: Float,
    val pressure: Float,       // 0f..1f, 0.5f default for finger/mouse
    val tiltX: Float = 0f,     // for calligraphy-style nib simulation
    val tiltY: Float = 0f,
    val timestampNanos: Long
) {
    fun toOffset() = Offset(x, y)
}

enum class PenType {
    HARD_BRUSH,      // Uniform width, crisp edges — default writing pen
    HIGHLIGHTER,     // Flat, translucent, wide, no width modulation
    INK_BRUSH,       // Chinese-ink style, soft edges, strong speed sensitivity
    BAMBOO_BRUSH,    // Textured, angular strokes
    SOFT_PEN,        // Calligraphy nib — thickness inversely proportional to speed
    LASER,           // Non-persistent, auto-fades, for presentation pointing
    MAGIC_PEN,       // Stamps shapes/particles instead of a plain line (stars, stamps)
    TEXTURE_PEN      // Chalk/crayon style repeating bitmap texture
}

enum class ShapeType {
    NONE, STRAIGHT_LINE, ARROW, DOTTED_LINE, DOUBLE_LINE, CURVE, ARC,
    RECTANGLE, ELLIPSE, TRIANGLE, POLYGON
}

/**
 * Everything needed to render + persist + edit a single freehand or shape stroke.
 * Kept flat and serializable so it can be written straight into the .enb-equivalent
 * document format (see [com.easiboard.app.model.Document]).
 */
@Serializable
data class Stroke(
    val id: String = UUID.randomUUID().toString(),
    val penType: PenType,
    val shapeType: ShapeType = ShapeType.NONE,
    val points: List<StrokePoint>,
    val colorArgb: Long,
    val baseWidthDp: Float,        // width the user picked in the pen panel
    val minWidthFactor: Float = 0.35f, // how thin the soft pen can get at max speed
    val maxWidthFactor: Float = 1.6f,  // how thick the soft pen can get at min speed
    val opacity: Float = 1f,
    val isEraser: Boolean = false,
    val locked: Boolean = false,
    val groupId: String? = null,
    val zIndex: Int = 0,
    val createdAtMillis: Long = System.currentTimeMillis()
) {
    /** Bounding box in canvas (world) coordinates — used for hit-testing, selection, culling. */
    fun bounds(): Bounds {
        if (points.isEmpty()) return Bounds(0f, 0f, 0f, 0f)
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE
        var maxX = Float.MIN_VALUE; var maxY = Float.MIN_VALUE
        for (p in points) {
            if (p.x < minX) minX = p.x
            if (p.y < minY) minY = p.y
            if (p.x > maxX) maxX = p.x
            if (p.y > maxY) maxY = p.y
        }
        val pad = baseWidthDp * maxWidthFactor
        return Bounds(minX - pad, minY - pad, maxX + pad, maxY + pad)
    }
}

@Serializable
data class Bounds(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    fun intersects(o: Bounds) = left <= o.right && right >= o.left && top <= o.bottom && bottom >= o.top
    fun contains(x: Float, y: Float) = x in left..right && y in top..bottom
}

/** A placed image, text box, or subject-tool widget (protractor, beaker, etc.) living on a page. */
@Serializable
data class CanvasObject(
    val id: String = UUID.randomUUID().toString(),
    val type: ObjectType,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val rotationDeg: Float = 0f,
    val payload: String,   // image URI, text content, or widget-specific JSON config
    val locked: Boolean = false,
    val zIndex: Int = 0
)

enum class ObjectType { IMAGE, TEXT, WIDGET_MATH, WIDGET_PHYSICS, WIDGET_CHEMISTRY, WIDGET_ENGLISH, MINI_BOARD }
