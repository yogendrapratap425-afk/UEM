package com.easiboard.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.unit.dp
import com.easiboard.app.engine.SoftPenPhysics
import com.easiboard.app.model.*
import com.easiboard.app.viewmodel.WhiteboardViewModel
import kotlin.math.max
import kotlin.math.min

/**
 * The infinite whiteboard surface.
 *
 * Coordinate spaces:
 *  - "Screen" space: raw pointer coordinates in pixels, as reported by Compose.
 *  - "World" space: the unbounded canvas coordinate system strokes are stored in.
 *    screen = world * zoom + pan
 *
 * Two independent gesture families run concurrently on the same pointer input:
 *  1. Single-pointer stylus/finger draw (when [ActiveTool.PEN]/[ActiveTool.ERASER]/[ActiveTool.SHAPE]
 *     is active) — captured with a low-level [PointerInputScope.awaitEachGesture] loop so we get
 *     raw pressure/tilt/historical points for the soft-pen physics.
 *  2. Two-finger pan/zoom ("roam") — always available regardless of tool, matching EasiNote's
 *     "you can always pinch to zoom, even mid-stroke-tool" behavior. Palm-rejection heuristics
 *     (below) stop an accidental resting palm from starting a stroke while a stylus is in range.
 */
@Composable
fun WhiteboardCanvas(vm: WhiteboardViewModel, modifier: Modifier = Modifier) {
    val inProgressPoints = remember { mutableStateListOf<StrokePoint>() }
    var stylusInRange by remember { mutableStateOf(false) }

    Canvas(
        modifier = modifier
            .pointerInput(vm.activeTool.value) {
                // --- Pan & zoom (two-finger) ---
                detectTransformGestures(panZoomLock = false) { _, panDelta, zoomDelta, _ ->
                    val newZoom = (vm.zoom.value * zoomDelta).coerceIn(0.1f, 8f)
                    vm.zoom.value = newZoom
                    vm.panX.value += panDelta.x
                    vm.panY.value += panDelta.y
                }
            }
            .pointerInput(vm.activeTool.value, vm.penSettings.value) {
                // --- Single-pointer draw / erase (stylus priority + basic palm rejection) ---
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)

                    // Palm rejection heuristic: if the touch is a large-area finger contact while
                    // a stylus was recently in hover range, ignore it. Real palm rejection also
                    // uses android.view.MotionEvent.TOOL_TYPE_ERASER / classification APIs which
                    // Compose exposes via down.type — checked here.
                    val isStylus = down.type == PointerType.Stylus || down.type == PointerType.Eraser
                    if (!isStylus && stylusInRange) return@awaitEachGesture

                    if (vm.activeTool.value == ActiveTool.ROAM) return@awaitEachGesture // roam handled by transform gestures only

                    inProgressPoints.clear()
                    inProgressPoints.add(down.toStrokePoint())

                    var pointer = down
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == pointer.id } ?: break
                        if (!change.pressed) {
                            inProgressPoints.add(change.toStrokePoint())
                            break
                        }
                        // Pull historical (batched) points for smoother high-frequency stylus input.
                        change.historical.forEach { inProgressPoints.add(it.toStrokePoint()) }
                        inProgressPoints.add(change.toStrokePoint())
                        change.consume()
                        pointer = change
                    }

                    when (vm.activeTool.value) {
                        ActiveTool.PEN, ActiveTool.SHAPE -> {
                            val worldPoints = inProgressPoints.map { it.toWorld(vm) }
                            vm.commitStroke(worldPoints)
                        }
                        ActiveTool.ERASER -> {
                            inProgressPoints.forEach {
                                val w = it.toWorld(vm)
                                vm.eraseAt(w.x, w.y, vm.eraserWidthDp.value)
                            }
                        }
                        else -> {}
                    }
                    inProgressPoints.clear()
                }
            }
    ) {
        drawBackground(vm.document.value.currentPage.background, vm.zoom.value, vm.panX.value, vm.panY.value)

        withTransform({
            translate(vm.panX.value, vm.panY.value)
            scale(vm.zoom.value, vm.zoom.value, pivot = Offset.Zero)
        }) {
            vm.currentStrokes.forEach { stroke -> drawStroke(stroke) }
        }

        // Live preview of the stroke currently being drawn, in screen space transform too.
        if (inProgressPoints.isNotEmpty() && vm.activeTool.value == ActiveTool.PEN) {
            withTransform({
                translate(vm.panX.value, vm.panY.value)
                scale(vm.zoom.value, vm.zoom.value, pivot = Offset.Zero)
            }) {
                val preview = Stroke(
                    penType = vm.penSettings.value.penType,
                    points = inProgressPoints.map { it.toWorld(vm) },
                    colorArgb = vm.penSettings.value.colorArgb,
                    baseWidthDp = vm.penSettings.value.widthDp,
                    opacity = vm.penSettings.value.opacity
                )
                drawStroke(preview)
            }
        }
    }
}

/** Convert a screen-space point (captured live during the gesture) into world space using
 *  the viewmodel's current pan/zoom — done at commit time so mid-stroke zoom changes don't
 *  distort the ink (EasiNote locks pan/zoom while a pen stroke is actively being drawn via
 *  the palm-rejection/single-pointer gate above, so this is safe). */
private fun StrokePoint.toWorld(vm: WhiteboardViewModel): StrokePoint = copy(
    x = (x - vm.panX.value) / vm.zoom.value,
    y = (y - vm.panY.value) / vm.zoom.value
)

private fun PointerInputChange.toStrokePoint() = StrokePoint(
    x = position.x,
    y = position.y,
    pressure = if (pressure.isNaN()) 0.5f else pressure,
    timestampNanos = uptimeMillis * 1_000_000L
)

private fun DrawScope.drawBackground(bg: PageBackground, zoom: Float, panX: Float, panY: Float) {
    val bgColor = Color(bg.colorArgb)
    drawRect(bgColor, size = size)
    val spacing = bg.gridSpacingDp.dp.toPx() * zoom
    if (spacing < 4f) return
    when (bg.style) {
        BackgroundStyle.GRID -> {
            val lineColor = bgColor.contrastGridColor()
            var x = panX % spacing
            while (x < size.width) { drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), 1f); x += spacing }
            var y = panY % spacing
            while (y < size.height) { drawLine(lineColor, Offset(0f, y), Offset(size.width, y), 1f); y += spacing }
        }
        BackgroundStyle.LINED -> {
            val lineColor = bgColor.contrastGridColor()
            var y = panY % (spacing * 2f)
            while (y < size.height) { drawLine(lineColor, Offset(0f, y), Offset(size.width, y), 1f); y += spacing * 2f }
        }
        BackgroundStyle.DOTTED -> {
            val dotColor = bgColor.contrastGridColor()
            var y = panY % spacing
            while (y < size.height) {
                var x = panX % spacing
                while (x < size.width) { drawCircle(dotColor, radius = 1.5f, center = Offset(x, y)); x += spacing }
                y += spacing
            }
        }
        BackgroundStyle.FOUR_LINE_ENGLISH -> {
            // Four ruled lines per row for English handwriting practice.
            val lineColor = bgColor.contrastGridColor()
            val rowHeight = spacing * 2f
            var y = panY % rowHeight
            while (y < size.height) {
                for (i in 0..3) {
                    val ly = y + i * (rowHeight / 3f)
                    val alpha = if (i == 0 || i == 3) 0.9f else 0.4f
                    drawLine(lineColor.copy(alpha = alpha), Offset(0f, ly), Offset(size.width, ly), 1f)
                }
                y += rowHeight
            }
        }
        else -> {} // BLANK, MUSIC_STAFF (drawn by a dedicated subject-tool overlay), CUSTOM_IMAGE (drawn via Image composable layer)
    }
}

private fun Color.contrastGridColor(): Color =
    if (luminance() > 0.5f) Color.Black.copy(alpha = 0.08f) else Color.White.copy(alpha = 0.10f)

/** Renders one stroke as a variable-width ribbon using [SoftPenPhysics] width factors. */
private fun DrawScope.drawStroke(stroke: Stroke) {
    if (stroke.points.size < 2) {
        // Single tap with a pen = a dot.
        stroke.points.firstOrNull()?.let {
            drawCircle(
                Color(stroke.colorArgb).copy(alpha = stroke.opacity),
                radius = (stroke.baseWidthDp / 2f),
                center = it.toOffset()
            )
        }
        return
    }

    val factors = SoftPenPhysics.computeWidthFactors(
        stroke.points, stroke.penType, stroke.minWidthFactor, stroke.maxWidthFactor
    )
    val baseColor = Color(stroke.colorArgb)
    val alpha = when (stroke.penType) {
        PenType.HIGHLIGHTER -> min(stroke.opacity, 0.35f)
        PenType.LASER -> 0.9f
        else -> stroke.opacity
    }
    val blendMode = if (stroke.penType == PenType.HIGHLIGHTER) BlendMode.Multiply else BlendMode.SrcOver

    for (i in 0 until stroke.points.size - 1) {
        val p1 = stroke.points[i].toOffset()
        val p2 = stroke.points[i + 1].toOffset()
        val w = SoftPenPhysics.clampWidthDp(stroke.baseWidthDp, factors[i])
        drawLine(
            color = baseColor.copy(alpha = alpha),
            start = p1,
            end = p2,
            strokeWidth = w,
            cap = StrokeCap.Round,
            blendMode = blendMode
        )
    }
}
