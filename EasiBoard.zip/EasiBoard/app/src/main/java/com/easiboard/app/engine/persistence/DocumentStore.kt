package com.easiboard.app.engine.persistence

import com.easiboard.app.model.Document
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Persists a [Document] as a single JSON manifest — the equivalent of Seewo's .enb format
 * (which is itself a renamed zip containing a manifest + embedded media). This scaffold
 * writes plain JSON; extending it to bundle embedded images/audio into a zip alongside
 * `manifest.json` is a mechanical next step (java.util.zip.ZipOutputStream).
 *
 * File extension used: ".easi" (this app's native format).
 */
class DocumentStore(private val boardsDir: File) {

    private val json = Json {
        prettyPrint = false
        ignoreUnknownKeys = true // forward-compatible with future fields
    }

    init {
        if (!boardsDir.exists()) boardsDir.mkdirs()
    }

    fun save(document: Document): File {
        val file = File(boardsDir, "${document.id}.easi")
        val payload = json.encodeToString(Document.serializer(), document)
        file.writeText(payload)
        return file
    }

    fun load(id: String): Document? {
        val file = File(boardsDir, "$id.easi")
        if (!file.exists()) return null
        return json.decodeFromString(Document.serializer(), file.readText())
    }

    fun listSavedBoards(): List<File> =
        boardsDir.listFiles { f -> f.extension == "easi" }?.toList() ?: emptyList()

    fun delete(id: String) {
        File(boardsDir, "$id.easi").delete()
    }
}

/**
 * Debounced autosave: call [notifyChanged] on every document mutation; it schedules a save
 * a few seconds out and coalesces bursts of edits (e.g. rapid strokes) into a single write,
 * so autosave never causes writing lag.
 */
class AutosaveManager(
    private val store: DocumentStore,
    private val intervalMillis: Long = 4_000L,
    private val scope: kotlinx.coroutines.CoroutineScope
) {
    private var pendingJob: kotlinx.coroutines.Job? = null

    fun notifyChanged(documentProvider: () -> Document) {
        pendingJob?.cancel()
        pendingJob = scope.launch {
            kotlinx.coroutines.delay(intervalMillis)
            store.save(documentProvider())
        }
    }
}
