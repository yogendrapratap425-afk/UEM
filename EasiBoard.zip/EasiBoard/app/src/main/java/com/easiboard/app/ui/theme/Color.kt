package com.easiboard.app.ui.theme

import androidx.compose.ui.graphics.Color

val EasiBlue80 = Color(0xFFA6C8FF)
val EasiBlue40 = Color(0xFF3B82F6)
val EasiBlueDark = Color(0xFF1D4ED8)

val SurfaceLight = Color(0xFFF7F8FA)
val SurfaceDark = Color(0xFF16181D)

val ToolbarLight = Color(0xFFFFFFFF)
val ToolbarDark = Color(0xFF23262E)

val CanvasWhite = Color(0xFFFFFFFF)
val CanvasBlack = Color(0xFF0E0E0E)
