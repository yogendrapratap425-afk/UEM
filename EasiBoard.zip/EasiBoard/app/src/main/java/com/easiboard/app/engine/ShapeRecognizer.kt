package com.easiboard.app.engine

import androidx.compose.ui.geometry.Offset
import com.easiboard.app.model.ShapeType
import com.easiboard.app.model.StrokePoint
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Lightweight geometric-feature recognizer (no ML model needed — this is the same class
 * of technique EasiNote/OneNote-style "ink to shape" uses for the common primitives).
 * Runs once when a freehand stroke ends, only when shape-recognition is enabled in the
 * pen panel ("Smart shape" toggle).
 */
object ShapeRecognizer {

    data class Result(val shapeType: ShapeType, val points: List<Offset>)

    /** Returns null if the stroke doesn't confidently match a known primitive
     *  (in which case the original freehand ink is kept as-is). */
    fun recognize(points: List<StrokePoint>): Result? {
        if (points.size < 8) return null
        val pts = points.map { Offset(it.x, it.y) }

        val start = pts.first()
        val end = pts.last()
        val closureDist = start.distanceTo(end)
        val bbox = boundingBox(pts)
        val diagonal = hypot(bbox.width.toDouble(), bbox.height.toDouble()).toFloat()
        val isClosed = closureDist < diagonal * 0.18f

        return when {
            isClosed && looksLikeEllipse(pts, bbox) -> Result(ShapeType.ELLIPSE, ellipsePoints(bbox))
            isClosed && looksLikePolygonOfSides(pts, 4) -> Result(ShapeType.RECTANGLE, rectPoints(bbox))
            isClosed && looksLikePolygonOfSides(pts, 3) -> Result(ShapeType.TRIANGLE, trianglePoints(pts))
            !isClosed && looksLikeStraightLine(pts) -> Result(ShapeType.STRAIGHT_LINE, listOf(start, end))
            else -> null
        }
    }

    private fun looksLikeStraightLine(pts: List<Offset>): Boolean {
        val start = pts.first(); val end = pts.last()
        val lineLen = start.distanceTo(end)
        if (lineLen < 1f) return false
        // Max perpendicular deviation of any sample point from the start-end chord.
        val maxDeviation = pts.maxOf { perpendicularDistance(it, start, end) }
        return maxDeviation / lineLen < 0.04f
    }

    private fun looksLikeEllipse(pts: List<Offset>, bbox: Rect): Boolean {
        val cx = bbox.left + bbox.width / 2f
        val cy = bbox.top + bbox.height / 2f
        val rx = bbox.width / 2f
        val ry = bbox.height / 2f
        if (rx < 1f || ry < 1f) return false
        // For each point, check how close it sits to the implied ellipse radius at its angle.
        var errorSum = 0f
        for (p in pts) {
            val nx = (p.x - cx) / rx
            val ny = (p.y - cy) / ry
            val r = hypot(nx.toDouble(), ny.toDouble()).toFloat()
            errorSum += abs(r - 1f)
        }
        val avgError = errorSum / pts.size
        return avgError < 0.16f
    }

    /** Approximate corner count via direction-change (angle delta) peaks, then check == sides. */
    private fun looksLikePolygonOfSides(pts: List<Offset>, sides: Int): Boolean {
        val corners = detectCorners(pts)
        return corners in (sides - 1)..(sides + 1) // tolerate hand jitter of +/-1 corner
    }

    private fun detectCorners(pts: List<Offset>): Int {
        if (pts.size < 5) return 0
        val angles = mutableListOf<Float>()
        val step = max(1, pts.size / 40) // downsample for stability on dense stylus input
        var i = step
        while (i < pts.size - step) {
            val a = pts[i - step]; val b = pts[i]; val c = pts[i + step]
            val v1 = Offset(b.x - a.x, b.y - a.y)
            val v2 = Offset(c.x - b.x, c.y - b.y)
            val angle1 = atan2(v1.y.toDouble(), v1.x.toDouble())
            val angle2 = atan2(v2.y.toDouble(), v2.x.toDouble())
            var delta = Math.toDegrees(angle2 - angle1).toFloat()
            while (delta > 180f) delta -= 360f
            while (delta < -180f) delta += 360f
            angles.add(abs(delta))
            i += step
        }
        return angles.count { it > 35f } // a "corner" = sharp direction change > 35 degrees
    }

    private fun max(a: Int, b: Int) = if (a > b) a else b

    private fun perpendicularDistance(p: Offset, a: Offset, b: Offset): Float {
        val num = abs((b.y - a.y) * p.x - (b.x - a.x) * p.y + b.x * a.y - b.y * a.x)
        val den = a.distanceTo(b)
        return if (den < 0.0001f) p.distanceTo(a) else num / den
    }

    private fun Offset.distanceTo(o: Offset) = hypot((x - o.x).toDouble(), (y - o.y).toDouble()).toFloat()

    private data class Rect(val left: Float, val top: Float, val width: Float, val height: Float)

    private fun boundingBox(pts: List<Offset>): Rect {
        val minX = pts.minOf { it.x }; val maxX = pts.maxOf { it.x }
        val minY = pts.minOf { it.y }; val maxY = pts.maxOf { it.y }
        return Rect(minX, minY, maxX - minX, maxY - minY)
    }

    private fun rectPoints(b: Rect) = listOf(
        Offset(b.left, b.top), Offset(b.left + b.width, b.top),
        Offset(b.left + b.width, b.top + b.height), Offset(b.left, b.top + b.height),
        Offset(b.left, b.top)
    )

    private fun ellipsePoints(b: Rect): List<Offset> {
        val cx = b.left + b.width / 2f; val cy = b.top + b.height / 2f
        val rx = b.width / 2f; val ry = b.height / 2f
        return (0..64).map {
            val t = (it / 64f) * 2 * Math.PI
            Offset(cx + rx * Math.cos(t).toFloat(), cy + ry * Math.sin(t).toFloat())
        }
    }

    private fun trianglePoints(pts: List<Offset>): List<Offset> {
        // Pick the 3 points that maximize enclosed area as an approximation of the true vertices.
        var best: Triple<Offset, Offset, Offset>? = null
        var bestArea = -1f
        val sampled = pts.filterIndexed { i, _ -> i % max(1, pts.size / 30) == 0 }
        for (a in sampled) for (b in sampled) for (c in sampled) {
            val area = abs((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y))
            if (area > bestArea) { bestArea = area; best = Triple(a, b, c) }
        }
        val (a, b, c) = best ?: return pts
        return listOf(a, b, c, a)
    }
}
