package com.easiboard.app.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.easiboard.app.engine.Command
import com.easiboard.app.engine.ShapeRecognizer
import com.easiboard.app.engine.UndoRedoManager
import com.easiboard.app.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Single source of truth for the whole board screen. Compose UI reads from this via
 * mutableStateOf/mutableStateListOf properties (Compose recomposes automatically on change),
 * while all mutation goes through [UndoRedoManager.execute] so nothing bypasses history.
 */
class WhiteboardViewModel : ViewModel() {

    // ---- Document / page state -------------------------------------------------
    val document = mutableStateOf(Document())
    val pages get() = document.value.pages

    // Strokes of the CURRENT page, exposed as a flat observable list for the canvas layer.
    val currentStrokes = mutableStateListOf<Stroke>()
    val currentObjects = mutableStateListOf<CanvasObject>()

    private val undoRedo = UndoRedoManager()
    val canUndo get() = undoRedo.canUndo
    val canRedo get() = undoRedo.canRedo

    // ---- Tool / mode state -------------------------------------------------------
    val activeTool = mutableStateOf(ActiveTool.PEN)
    val appMode = mutableStateOf(AppMode.STANDARD)
    val subjectMode get() = document.value.subjectMode
    val penSettings = mutableStateOf(PenSettings())
    val eraserMode = mutableStateOf(EraserMode.POINT)
    val eraserWidthDp = mutableStateOf(24f)
    val activeShapeType = mutableStateOf(ShapeType.STRAIGHT_LINE)
    val smartShapeRecognitionEnabled = mutableStateOf(true)
    val recentColors = mutableStateListOf<Long>()

    // ---- Viewport (infinite canvas pan/zoom) -------------------------------------
    val panX = mutableStateOf(0f)
    val panY = mutableStateOf(0f)
    val zoom = mutableStateOf(1f)

    // ---- Overlay tools ------------------------------------------------------------
    val spotlightActive = mutableStateOf(false)
    val screenShadeActive = mutableStateOf(false)
    val toolbarExpanded = mutableStateOf(true)
    val toolbarOffsetX = mutableStateOf(0f)
    val toolbarOffsetY = mutableStateOf(0f)

    init {
        syncCurrentPageArrays()
    }

    // ---- Page navigation ----------------------------------------------------------

    fun goToPage(index: Int) {
        if (index !in pages.indices) return
        document.value = document.value.also { it.currentPageIndex = index }
        syncCurrentPageArrays()
        undoRedo.clear() // page-scoped history keeps memory bounded; cross-page ops handled separately
    }

    fun nextPage() = goToPage(document.value.currentPageIndex + 1)
    fun prevPage() = goToPage(document.value.currentPageIndex - 1)

    fun addPage(afterCurrent: Boolean = true) {
        val insertAt = if (afterCurrent) document.value.currentPageIndex + 1 else pages.size
        val newPage = Page(
            background = document.value.currentPage.background.copy() // inherit background style
        )
        pages.add(insertAt, newPage)
        goToPage(insertAt)
    }

    fun deletePage(index: Int) {
        if (pages.size <= 1) return // never allow zero pages
        pages.removeAt(index)
        val newIndex = index.coerceAtMost(pages.lastIndex)
        goToPage(newIndex)
    }

    fun duplicatePage(index: Int) {
        val src = pages[index]
        val copy = src.copy(
            id = java.util.UUID.randomUUID().toString(),
            strokes = src.strokes.toMutableList(),
            objects = src.objects.toMutableList()
        )
        pages.add(index + 1, copy)
        goToPage(index + 1)
    }

    private fun syncCurrentPageArrays() {
        currentStrokes.clear(); currentStrokes.addAll(document.value.currentPage.strokes)
        currentObjects.clear(); currentObjects.addAll(document.value.currentPage.objects)
    }

    // ---- Stroke lifecycle (called from the canvas gesture handler) ----------------

    /** Called once, when a raw freehand stroke is finished — applies optional shape
     *  recognition, wraps the mutation as an undoable [Command], and commits it. */
    fun commitStroke(rawPoints: List<StrokePoint>) {
        if (rawPoints.size < 2) return

        var finalShape = ShapeType.NONE
        var finalPoints = rawPoints

        if (activeTool.value == ActiveTool.SHAPE) {
            finalShape = activeShapeType.value
        } else if (activeTool.value == ActiveTool.PEN && smartShapeRecognitionEnabled.value) {
            ShapeRecognizer.recognize(rawPoints)?.let { result ->
                finalShape = result.shapeType
                finalPoints = result.points.mapIndexed { i, o ->
                    StrokePoint(o.x, o.y, 0.6f, timestampNanos = rawPoints.getOrNull(i)?.timestampNanos ?: 0L)
                }
            }
        }

        val stroke = Stroke(
            penType = penSettings.value.penType,
            shapeType = finalShape,
            points = finalPoints,
            colorArgb = penSettings.value.colorArgb,
            baseWidthDp = penSettings.value.widthDp,
            opacity = penSettings.value.opacity,
            zIndex = currentStrokes.size
        )

        undoRedo.execute(object : Command {
            override val label = "Add stroke"
            override fun apply() {
                currentStrokes.add(stroke)
                document.value.currentPage.strokes.add(stroke)
            }
            override fun revert() {
                currentStrokes.remove(stroke)
                document.value.currentPage.strokes.remove(stroke)
            }
        })

        pushRecentColor(penSettings.value.colorArgb)

        // Laser pen: auto-fade after a short delay instead of persisting.
        if (penSettings.value.penType == PenType.LASER) {
            viewModelScope.launch {
                delay(1200)
                currentStrokes.remove(stroke)
                document.value.currentPage.strokes.remove(stroke)
            }
        }
    }

    /** Erase any stroke whose bounds are hit by the eraser path (point/area modes). */
    fun eraseAt(worldX: Float, worldY: Float, radiusDp: Float) {
        val hits = currentStrokes.filter { !it.locked && it.bounds().contains(worldX, worldY) }
        if (hits.isEmpty()) return
        undoRedo.execute(object : Command {
            override val label = "Erase"
            val removed = hits
            override fun apply() {
                currentStrokes.removeAll(removed)
                document.value.currentPage.strokes.removeAll(removed)
            }
            override fun revert() {
                currentStrokes.addAll(removed)
                document.value.currentPage.strokes.addAll(removed)
            }
        })
    }

    fun clearPage() {
        val backup = currentStrokes.toList()
        undoRedo.execute(object : Command {
            override val label = "Clear page"
            override fun apply() {
                currentStrokes.clear()
                document.value.currentPage.strokes.clear()
            }
            override fun revert() {
                currentStrokes.addAll(backup)
                document.value.currentPage.strokes.addAll(backup)
            }
        })
    }

    fun undo() { undoRedo.undo(); resyncFromModel() }
    fun redo() { undoRedo.redo(); resyncFromModel() }

    private fun resyncFromModel() {
        currentStrokes.clear(); currentStrokes.addAll(document.value.currentPage.strokes)
    }

    private fun pushRecentColor(color: Long) {
        recentColors.remove(color)
        recentColors.add(0, color)
        while (recentColors.size > 10) recentColors.removeAt(recentColors.lastIndex)
    }

    // ---- Tool selection helpers -----------------------------------------------------

    fun selectPen(type: PenType) {
        activeTool.value = ActiveTool.PEN
        penSettings.value = penSettings.value.copy(penType = type)
    }

    fun setSubjectMode(mode: SubjectMode) {
        document.value = document.value.also { it.subjectMode = mode }
    }
}
