package com.easiboard.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.easiboard.app.model.ObjectType
import com.easiboard.app.model.SubjectMode
import com.easiboard.app.viewmodel.WhiteboardViewModel
import java.util.UUID

private data class SubjectWidget(val label: String, val objectType: ObjectType, val configId: String)

private val MATH_WIDGETS = listOf(
    SubjectWidget("Compass", ObjectType.WIDGET_MATH, "compass"),
    SubjectWidget("Protractor", ObjectType.WIDGET_MATH, "protractor"),
    SubjectWidget("Ruler", ObjectType.WIDGET_MATH, "ruler"),
    SubjectWidget("Set Square", ObjectType.WIDGET_MATH, "set_square"),
    SubjectWidget("Graph Paper", ObjectType.WIDGET_MATH, "graph_paper"),
    SubjectWidget("Function Grapher", ObjectType.WIDGET_MATH, "function_grapher"),
    SubjectWidget("3D Shapes", ObjectType.WIDGET_MATH, "shapes_3d")
)

private val PHYSICS_WIDGETS = listOf(
    SubjectWidget("Ammeter", ObjectType.WIDGET_PHYSICS, "ammeter"),
    SubjectWidget("Voltmeter", ObjectType.WIDGET_PHYSICS, "voltmeter"),
    SubjectWidget("Rheostat", ObjectType.WIDGET_PHYSICS, "rheostat"),
    SubjectWidget("Battery", ObjectType.WIDGET_PHYSICS, "battery"),
    SubjectWidget("Force Vector", ObjectType.WIDGET_PHYSICS, "force_vector"),
    SubjectWidget("Circuit Wire", ObjectType.WIDGET_PHYSICS, "wire")
)

private val CHEMISTRY_WIDGETS = listOf(
    SubjectWidget("Beaker", ObjectType.WIDGET_CHEMISTRY, "beaker"),
    SubjectWidget("Test Tube", ObjectType.WIDGET_CHEMISTRY, "test_tube"),
    SubjectWidget("Periodic Table", ObjectType.WIDGET_CHEMISTRY, "periodic_table"),
    SubjectWidget("Atomic Model", ObjectType.WIDGET_CHEMISTRY, "atomic_model"),
    SubjectWidget("Bunsen Burner", ObjectType.WIDGET_CHEMISTRY, "burner")
)

private val ENGLISH_WIDGETS = listOf(
    SubjectWidget("Four-Line Grid", ObjectType.WIDGET_ENGLISH, "four_line_grid"),
    SubjectWidget("Phonetic Symbols", ObjectType.WIDGET_ENGLISH, "phonetics_chart")
)

/**
 * The "Treasure Chest" — subject-aware tool drawer. Tapping a widget drops an instance
 * of it onto the center of the current viewport as a [com.easiboard.app.model.CanvasObject];
 * each widget type then renders its own interactive Composable overlay (compass that can be
 * rotated to draw an arc, protractor with a readable angle, etc.) — those per-widget
 * interactive renderers are the natural next slice of work after this scaffold.
 */
@Composable
fun TreasureChestPanel(vm: WhiteboardViewModel, modifier: Modifier = Modifier) {
    val widgets = when (vm.subjectMode) {
        SubjectMode.MATH -> MATH_WIDGETS
        SubjectMode.PHYSICS -> PHYSICS_WIDGETS
        SubjectMode.CHEMISTRY -> CHEMISTRY_WIDGETS
        SubjectMode.ENGLISH, SubjectMode.CHINESE -> ENGLISH_WIDGETS
        SubjectMode.GENERAL -> MATH_WIDGETS.take(3) + PHYSICS_WIDGETS.take(2) // handy default mix
    }

    Column(
        modifier = modifier
            .width(280.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Text("Treasure Chest", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        // Subject switcher
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SubjectMode.entries.forEach { mode ->
                FilterChip(
                    selected = vm.subjectMode == mode,
                    onClick = { vm.setSubjectMode(mode) },
                    label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.height(260.dp)
        ) {
            items(widgets) { widget ->
                OutlinedCard(
                    onClick = { placeWidgetOnCanvas(vm, widget) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(64.dp),
                        contentAlignment = androidx.compose.ui.Alignment.Center
                    ) {
                        Text(widget.label, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

private fun placeWidgetOnCanvas(vm: WhiteboardViewModel, widget: SubjectWidget) {
    val centerWorldX = (-vm.panX.value + 400f) / vm.zoom.value
    val centerWorldY = (-vm.panY.value + 300f) / vm.zoom.value
    val obj = com.easiboard.app.model.CanvasObject(
        id = UUID.randomUUID().toString(),
        type = widget.objectType,
        x = centerWorldX,
        y = centerWorldY,
        width = 180f,
        height = 180f,
        payload = widget.configId
    )
    vm.currentObjects.add(obj)
    vm.document.value.currentPage.objects.add(obj)
}
