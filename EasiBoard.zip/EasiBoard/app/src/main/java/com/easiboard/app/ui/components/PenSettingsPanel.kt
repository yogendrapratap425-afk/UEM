package com.easiboard.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.easiboard.app.model.DEFAULT_PALETTE
import com.easiboard.app.model.PenType
import com.easiboard.app.viewmodel.WhiteboardViewModel

private data class PenTypeUi(val type: PenType, val label: String)

private val PEN_TYPES = listOf(
    PenTypeUi(PenType.HARD_BRUSH, "Hard Brush"),
    PenTypeUi(PenType.HIGHLIGHTER, "Highlighter"),
    PenTypeUi(PenType.INK_BRUSH, "Ink Brush"),
    PenTypeUi(PenType.BAMBOO_BRUSH, "Bamboo Brush"),
    PenTypeUi(PenType.SOFT_PEN, "Soft Pen"),
    PenTypeUi(PenType.LASER, "Laser Pointer"),
    PenTypeUi(PenType.MAGIC_PEN, "Magic Pen"),
    PenTypeUi(PenType.TEXTURE_PEN, "Texture Pen")
)

@Composable
fun PenSettingsPanel(vm: WhiteboardViewModel, modifier: Modifier = Modifier) {
    val settings = vm.penSettings.value

    Column(
        modifier = modifier
            .width(320.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Text("Pen", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))

        // --- Pen type chips ---
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(PEN_TYPES) { pt ->
                FilterChip(
                    selected = settings.penType == pt.type,
                    onClick = { vm.penSettings.value = settings.copy(penType = pt.type) },
                    label = { Text(pt.label) }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // --- Thickness slider with live preview dot ---
        Text("Thickness: ${settings.widthDp.toInt()} dp", style = MaterialTheme.typography.labelSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Slider(
                value = settings.widthDp,
                onValueChange = { vm.penSettings.value = settings.copy(widthDp = it) },
                valueRange = 1f..48f,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .padding(start = 8.dp)
                    .size(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size((settings.widthDp.coerceAtMost(32f)).dp)
                        .clip(CircleShape)
                        .background(Color(settings.colorArgb))
                )
            }
        }

        // --- Opacity (relevant mainly for highlighter/texture pen) ---
        Spacer(Modifier.height(8.dp))
        Text("Opacity: ${(settings.opacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
        Slider(
            value = settings.opacity,
            onValueChange = { vm.penSettings.value = settings.copy(opacity = it) },
            valueRange = 0.1f..1f
        )

        Spacer(Modifier.height(12.dp))

        // --- Recent colors ---
        if (vm.recentColors.isNotEmpty()) {
            Text("Recent", style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(vm.recentColors) { c ->
                    ColorSwatch(c, selected = settings.colorArgb == c) {
                        vm.penSettings.value = settings.copy(colorArgb = c)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        // --- Full 42-color palette ---
        Text("Palette", style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(4.dp))
        PaletteGrid(
            selectedColor = settings.colorArgb,
            onColorSelected = { vm.penSettings.value = settings.copy(colorArgb = it) }
        )

        Spacer(Modifier.height(12.dp))

        // --- Smart shape recognition toggle (applies to freehand pen strokes) ---
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Smart shape recognition", style = MaterialTheme.typography.bodyLarge)
            Switch(
                checked = vm.smartShapeRecognitionEnabled.value,
                onCheckedChange = { vm.smartShapeRecognitionEnabled.value = it }
            )
        }
    }
}

@Composable
private fun PaletteGrid(selectedColor: Long, onColorSelected: (Long) -> Unit) {
    // Simple wrap-style grid using Row+chunked to avoid pulling in a LazyVerticalGrid
    // dependency conflict for this snippet-sized panel; swap for LazyVerticalGrid in prod.
    val rows = DEFAULT_PALETTE.chunked(7)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { c -> ColorSwatch(c, selected = c == selectedColor) { onColorSelected(c) } }
            }
        }
    }
}

@Composable
private fun ColorSwatch(colorArgb: Long, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(Color(colorArgb))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.1f),
                shape = CircleShape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                Icons.Filled.Check,
                contentDescription = "Selected",
                tint = if (Color(colorArgb).luminance() > 0.5f) Color.Black else Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}
