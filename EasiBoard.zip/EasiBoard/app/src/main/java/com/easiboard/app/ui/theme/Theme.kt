package com.easiboard.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = EasiBlue40,
    onPrimary = Color.White,
    secondary = EasiBlueDark,
    surface = SurfaceLight,
    background = SurfaceLight
)

private val DarkColors = darkColorScheme(
    primary = EasiBlue80,
    onPrimary = Color.Black,
    secondary = EasiBlue40,
    surface = SurfaceDark,
    background = SurfaceDark
)

@Composable
fun EasiBoardTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = EasiBoardTypography, content = content)
}
