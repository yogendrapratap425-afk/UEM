package com.easiboard.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.easiboard.app.viewmodel.WhiteboardViewModel

/**
 * Right-hand sidebar showing every page as a small preview card. Tapping navigates,
 * long-press-free icon buttons handle duplicate/delete so it stays simple and
 * finger-friendly on a tablet (no drag-reorder in this scaffold — straightforward
 * to add with androidx.compose.foundation ReorderableLazyColumn / Accompanist).
 */
@Composable
fun PageThumbnailBar(vm: WhiteboardViewModel, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .width(160.dp)
            .background(MaterialTheme.colorScheme.surface)
            .padding(8.dp)
    ) {
        Text("Pages (${vm.pages.size})", style = MaterialTheme.typography.labelSmall)
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(vm.pages) { index, page ->
                val isCurrent = index == vm.document.value.currentPageIndex
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            width = if (isCurrent) 2.dp else 1.dp,
                            color = if (isCurrent) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { vm.goToPage(index) }
                        .padding(6.dp)
                ) {
                    // Lightweight thumbnail placeholder: a mini scaled render of stroke bounding
                    // boxes would go here in production (rasterize page -> Bitmap on background
                    // thread, cache by page.thumbnailPath, invalidate on edit).
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .background(Color(page.background.colorArgb), RoundedCornerShape(6.dp))
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${index + 1}", style = MaterialTheme.typography.labelSmall)
                        Row {
                            IconButton(onClick = { vm.duplicatePage(index) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = "Duplicate page")
                            }
                            IconButton(onClick = { vm.deletePage(index) }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Filled.Delete, contentDescription = "Delete page")
                            }
                        }
                    }
                }
            }

            item {
                OutlinedButton(
                    onClick = { vm.addPage() },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Add page")
                }
            }
        }
    }
}
