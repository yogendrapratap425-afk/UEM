package com.easiboard.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/**
 * Darkens the whole screen except a movable/resizable circular (or rectangular) "spotlight"
 * region — used to focus student attention on one part of the board.
 */
@Composable
fun SpotlightOverlay(modifier: Modifier = Modifier) {
    var center by remember { mutableStateOf(Offset(400f, 400f)) }
    var radius by remember { mutableStateOf(220f) }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .pointerInput(Unit) {
                detectTransformGestures { centroid, pan, zoom, _ ->
                    center += pan
                    radius = (radius * zoom).coerceIn(80f, 900f)
                }
            }
    ) {
        // Dark scrim everywhere...
        drawRect(Color.Black.copy(alpha = 0.65f))
        // ...then punch a transparent hole using DstOut blending.
        drawCircle(
            color = Color.Transparent,
            radius = radius,
            center = center,
            blendMode = BlendMode.Clear
        )
    }
}

/**
 * Screen curtain: a solid panel that can be dragged away (from any of the 4 edges, here
 * simplified to "reveal from left") to progressively uncover the board underneath —
 * used for revealing answers one at a time.
 */
@Composable
fun ScreenShadeOverlay(modifier: Modifier = Modifier) {
    var revealFraction by remember { mutableStateOf(0.35f) } // 0 = fully covered, 1 = fully revealed

    Box(modifier = modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(1f - revealFraction)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        revealFraction = (revealFraction + drag.x / size.width).coerceIn(0f, 1f)
                    }
                },
            contentAlignment = Alignment.CenterEnd
        ) {
            IconButton(onClick = { revealFraction = (revealFraction + 0.15f).coerceAtMost(1f) }) {
                Icon(Icons.Filled.ChevronRight, contentDescription = "Drag or tap to reveal more")
            }
        }
    }
}
