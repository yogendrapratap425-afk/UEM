package com.easiboard.app.engine.recording

import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * TODO (next slice of work): wire up MediaProjectionManager + MediaRecorder here.
 * Flow: MainActivity requests MediaProjection permission via
 * registerForActivityResult(ActivityResultContracts.StartActivityForResult()),
 * passes the resulting Intent to this service, which then runs a foreground
 * notification (required on Android 10+) while recording video+mic audio to
 * a .mp4 in app-specific external storage, matching EasiNote's "Screen Record" tool.
 */
class ScreenRecordService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Intentionally unimplemented in this scaffold.
        return START_NOT_STICKY
    }
}
