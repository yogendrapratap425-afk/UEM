package com.easiboard.app

import android.app.Application

/**
 * App-wide init point. Wire up DI (Hilt/Koin), crash reporting, and the autosave
 * scheduler (see [com.easiboard.app.engine.persistence.AutosaveManager] — next slice
 * of work) from here in a production build.
 */
class EasiBoardApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
