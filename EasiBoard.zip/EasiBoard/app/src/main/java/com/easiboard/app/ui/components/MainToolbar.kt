package com.easiboard.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import com.easiboard.app.model.ActiveTool
import com.easiboard.app.viewmodel.WhiteboardViewModel

/**
 * The main floating toolbar. Matches the EasiNote layout: a horizontal pill of icon
 * buttons that can be (a) collapsed to a small handle, and (b) dragged anywhere on
 * screen by long-press-drag on the handle, exactly like the real product's floating bar.
 */
@Composable
fun MainToolbar(
    vm: WhiteboardViewModel,
    onOpenPenPanel: () -> Unit,
    onOpenTreasureChest: () -> Unit,
    onOpenPageThumbnails: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptics = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .offset { androidx.compose.ui.unit.IntOffset(vm.toolbarOffsetX.value.toInt(), vm.toolbarOffsetY.value.toInt()) }
    ) {
        AnimatedVisibility(visible = vm.toolbarExpanded.value) {
            Row(
                modifier = Modifier
                    .shadow(8.dp, RoundedCornerShape(28.dp))
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(28.dp))
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                DragHandle(vm)

                ToolbarIconButton(Icons.Filled.Menu, "Menu") { }
                ToolbarIconButton(Icons.Filled.DesktopWindows, "Desktop/Annotation") {
                    vm.appMode.value = if (vm.appMode.value == com.easiboard.app.model.AppMode.DESKTOP_ANNOTATION)
                        com.easiboard.app.model.AppMode.STANDARD else com.easiboard.app.model.AppMode.DESKTOP_ANNOTATION
                }
                ToolbarIconButton(Icons.Filled.Inventory2, "Treasure Chest") { onOpenTreasureChest() }
                ToolbarIconButton(Icons.Filled.PhotoLibrary, "Resource Pool") { }

                ToolbarDivider()

                ToolbarIconButton(
                    Icons.Filled.HighlightAlt, "Select",
                    selected = vm.activeTool.value == ActiveTool.SELECT
                ) { vm.activeTool.value = ActiveTool.SELECT }

                ToolbarIconButton(
                    Icons.Filled.Edit, "Pen",
                    selected = vm.activeTool.value == ActiveTool.PEN
                ) {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    vm.activeTool.value = ActiveTool.PEN
                    onOpenPenPanel()
                }

                ToolbarIconButton(
                    Icons.Filled.CleaningServices, "Eraser",
                    selected = vm.activeTool.value == ActiveTool.ERASER
                ) { vm.activeTool.value = ActiveTool.ERASER }

                ToolbarIconButton(
                    Icons.Filled.ShowChart, "Shapes",
                    selected = vm.activeTool.value == ActiveTool.SHAPE
                ) { vm.activeTool.value = ActiveTool.SHAPE }

                ToolbarIconButton(Icons.Filled.Image, "Insert Image") { vm.activeTool.value = ActiveTool.IMAGE }
                ToolbarIconButton(Icons.Filled.TextFields, "Text") { vm.activeTool.value = ActiveTool.TEXT }
                ToolbarIconButton(Icons.Filled.FormatColorFill, "Fill") { vm.activeTool.value = ActiveTool.FILL }

                ToolbarIconButton(
                    Icons.Filled.PanTool, "Roam",
                    selected = vm.activeTool.value == ActiveTool.ROAM
                ) { vm.activeTool.value = ActiveTool.ROAM }

                ToolbarDivider()

                ToolbarIconButton(Icons.Filled.Undo, "Undo", enabled = vm.canUndo) { vm.undo() }
                ToolbarIconButton(Icons.Filled.Redo, "Redo", enabled = vm.canRedo) { vm.redo() }

                ToolbarDivider()

                ToolbarIconButton(Icons.Filled.ChevronLeft, "Previous Page") { vm.prevPage() }
                ToolbarIconButton(Icons.Filled.GridView, "Pages") { onOpenPageThumbnails() }
                ToolbarIconButton(Icons.Filled.AddBox, "Add Page") { vm.addPage() }
                ToolbarIconButton(Icons.Filled.ChevronRight, "Next Page") { vm.nextPage() }

                ToolbarDivider()

                ToolbarIconButton(
                    Icons.Filled.CenterFocusStrong, "Spotlight",
                    selected = vm.spotlightActive.value
                ) { vm.spotlightActive.value = !vm.spotlightActive.value }

                ToolbarIconButton(
                    Icons.Filled.Blinds, "Screen Shade",
                    selected = vm.screenShadeActive.value
                ) { vm.screenShadeActive.value = !vm.screenShadeActive.value }

                ToolbarIconButton(Icons.Filled.FiberManualRecord, "Screen Record") { }

                IconButton(onClick = { vm.toolbarExpanded.value = false }) {
                    Icon(Icons.Filled.UnfoldLess, contentDescription = "Collapse toolbar")
                }
            }
        }

        AnimatedVisibility(visible = !vm.toolbarExpanded.value) {
            FloatingActionButton(
                onClick = { vm.toolbarExpanded.value = true },
                modifier = Modifier.pointerInput(Unit) {
                    detectDragGestures { change, drag ->
                        change.consume()
                        vm.toolbarOffsetX.value += drag.x
                        vm.toolbarOffsetY.value += drag.y
                    }
                }
            ) { Icon(Icons.Filled.UnfoldMore, contentDescription = "Expand toolbar") }
        }
    }
}

@Composable
private fun DragHandle(vm: WhiteboardViewModel) {
    Box(
        modifier = Modifier
            .size(20.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    vm.toolbarOffsetX.value += drag.x
                    vm.toolbarOffsetY.value += drag.y
                }
            }
    ) {
        Icon(Icons.Filled.DragIndicator, contentDescription = "Move toolbar", tint = Color.Gray)
    }
}

@Composable
private fun ToolbarIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val haptics = LocalHapticFeedback.current
    IconButton(
        onClick = {
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        },
        enabled = enabled,
        modifier = Modifier
            .size(44.dp)
            .then(
                if (selected) Modifier.background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp))
                else Modifier
            )
    ) {
        Icon(icon, contentDescription = label)
    }
}

@Composable
private fun ToolbarDivider() {
    Box(
        Modifier
            .padding(horizontal = 4.dp)
            .width(1.dp)
            .height(28.dp)
            .background(MaterialTheme.colorScheme.outlineVariant)
    )
}
