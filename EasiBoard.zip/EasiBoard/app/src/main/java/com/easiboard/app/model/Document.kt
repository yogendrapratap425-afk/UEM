package com.easiboard.app.model

import kotlinx.serialization.Serializable
import java.util.UUID

enum class BackgroundStyle { BLANK, GRID, LINED, DOTTED, MUSIC_STAFF, FOUR_LINE_ENGLISH, CUSTOM_IMAGE }

@Serializable
data class PageBackground(
    val style: BackgroundStyle = BackgroundStyle.BLANK,
    val colorArgb: Long = 0xFFFFFFFF,   // white by default; supports black / any custom color
    val imageUri: String? = null,       // used when style == CUSTOM_IMAGE
    val gridSpacingDp: Float = 24f
)

/**
 * A single whiteboard page. World coordinates are unbounded (the canvas is conceptually
 * infinite); [worldWidth]/[worldHeight] just define the "page frame" used for thumbnails,
 * PDF export, and the initial visible viewport — strokes may still exist outside of it if
 * the teacher pans/zooms and draws beyond the frame (EasiNote allows this "roam" behavior).
 */
@Serializable
data class Page(
    val id: String = UUID.randomUUID().toString(),
    var background: PageBackground = PageBackground(),
    val strokes: MutableList<Stroke> = mutableListOf(),
    val objects: MutableList<CanvasObject> = mutableListOf(),
    val worldWidth: Float = 1920f,
    val worldHeight: Float = 1080f,
    var thumbnailPath: String? = null,
    var lastModifiedMillis: Long = System.currentTimeMillis()
)

enum class SubjectMode { GENERAL, MATH, PHYSICS, CHEMISTRY, ENGLISH, CHINESE }

/**
 * The full "notebook" — equivalent of a Seewo .enb file. Serialized to JSON on autosave;
 * a real production build would additionally zip embedded images/audio alongside this
 * manifest the way .enb (a renamed zip) does.
 */
@Serializable
data class Document(
    val id: String = UUID.randomUUID().toString(),
    var title: String = "Untitled Board",
    val pages: MutableList<Page> = mutableListOf(Page()),
    var currentPageIndex: Int = 0,
    var subjectMode: SubjectMode = SubjectMode.GENERAL,
    var createdAtMillis: Long = System.currentTimeMillis(),
    var updatedAtMillis: Long = System.currentTimeMillis()
) {
    val currentPage: Page get() = pages[currentPageIndex.coerceIn(0, pages.lastIndex)]
}
