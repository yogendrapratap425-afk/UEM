package com.easiboard.app.model

import kotlinx.serialization.Serializable

/** Every entry a teacher can tap on the main toolbar. Order here is the default order;
 *  [com.easiboard.app.viewmodel.ToolbarLayoutState] lets the user drag to reorder/hide. */
enum class ToolbarItem {
    MENU,
    MODE_SWITCH,            // Desktop / Annotation mode toggle
    TREASURE_CHEST,         // Subject tools drawer
    RESOURCE_POOL,
    SELECT,                 // lasso + multi-select
    PEN,
    ERASER,
    SHAPES,
    IMAGE_INSERT,
    TEXT,
    FILL,
    ROAM,                   // pan/hand tool
    UNDO,
    REDO,
    PAGE_PREV,
    PAGE_THUMBNAILS,
    PAGE_ADD,
    PAGE_NEXT,
    SPOTLIGHT,
    SCREEN_SHADE,
    SCREEN_RECORD
}

enum class ActiveTool {
    PEN, ERASER, SELECT, SHAPE, TEXT, IMAGE, FILL, ROAM, SPOTLIGHT, SCREEN_SHADE
}

enum class EraserMode { POINT, AREA, LASSO }

enum class AppMode { STANDARD, CONCISE, DESKTOP_ANNOTATION }

@Serializable
data class PenPreset(
    val penType: PenType,
    val colorArgb: Long,
    val widthDp: Float,
    val opacity: Float = 1f,
    val name: String = ""
)

/** Live, in-memory settings for whichever pen is currently selected — read by the canvas
 *  on every stroke start. Kept separate from [PenPreset] (saved favorites). */
data class PenSettings(
    val penType: PenType = PenType.HARD_BRUSH,
    val colorArgb: Long = 0xFF1A1A1AL,
    val widthDp: Float = 4f,
    val opacity: Float = 1f
)

val DEFAULT_PALETTE: List<Long> = listOf(
    0xFF000000, 0xFFFFFFFF, 0xFFEF4444, 0xFFF97316, 0xFFF59E0B, 0xFFEAB308,
    0xFF84CC16, 0xFF22C55E, 0xFF10B981, 0xFF14B8A6, 0xFF06B6D4, 0xFF0EA5E9,
    0xFF3B82F6, 0xFF6366F1, 0xFF8B5CF6, 0xFFA855F7, 0xFFD946EF, 0xFFEC4899,
    0xFFF43F5E, 0xFF64748B, 0xFF475569, 0xFF1E293B, 0xFF7C2D12, 0xFF78350F,
    0xFF365314, 0xFF14532D, 0xFF134E4A, 0xFF164E63, 0xFF1E3A8A, 0xFF312E81,
    0xFF4C1D95, 0xFF581C87, 0xFF831843, 0xFF7F1D1D, 0xFFFCA5A5, 0xFFFDBA74,
    0xFFFDE68A, 0xFFBEF264, 0xFF86EFAC, 0xFF67E8F9, 0xFF93C5FD, 0xFFC4B5FD,
    0xFFF9A8D4, 0xFFE5E7EB
) // 42 swatches, matches spec's "42+ color palette" baseline
