package com.easiboard.app.engine.overlay

import android.app.Service
import android.content.Intent
import android.os.IBinder

/**
 * TODO (next slice of work): implement "Desktop/Annotation Mode" — draw on top of any
 * app or the home screen. Approach: WindowManager.addView() with a TYPE_APPLICATION_OVERLAY
 * window hosting a transparent ComposeView that reuses [com.easiboard.app.ui.components.WhiteboardCanvas],
 * gated behind the SYSTEM_ALERT_WINDOW special permission (Settings.canDrawOverlays check +
 * ACTION_MANAGE_OVERLAY_PERMISSION request flow). A small floating "back to app" pill stays
 * on top so the teacher can return to EasiBoard.
 */
class AnnotationOverlayService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
}
