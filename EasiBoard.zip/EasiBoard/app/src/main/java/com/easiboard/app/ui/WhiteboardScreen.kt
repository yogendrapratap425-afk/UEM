package com.easiboard.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.easiboard.app.ui.components.*
import com.easiboard.app.viewmodel.WhiteboardViewModel

/**
 * Top-level screen: infinite canvas fills the background; the floating toolbar and any
 * open popovers (pen settings, treasure chest, page thumbnails) float above it. This
 * mirrors EasiNote's layering model where the canvas never gets "pushed" by UI chrome —
 * panels float over it so the drawing surface is never resized mid-lesson.
 */
@Composable
fun WhiteboardScreen(vm: WhiteboardViewModel = viewModel()) {
    var showPenPanel by remember { mutableStateOf(false) }
    var showTreasureChest by remember { mutableStateOf(false) }
    var showPageThumbnails by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Box(modifier = Modifier.fillMaxSize()) {

            WhiteboardCanvas(vm = vm, modifier = Modifier.fillMaxSize())

            if (vm.spotlightActive.value) {
                SpotlightOverlay(modifier = Modifier.fillMaxSize())
            }
            if (vm.screenShadeActive.value) {
                ScreenShadeOverlay(modifier = Modifier.fillMaxSize())
            }

            if (showPageThumbnails) {
                PageThumbnailBar(
                    vm = vm,
                    modifier = Modifier.align(Alignment.CenterEnd).fillMaxHeight().padding(8.dp)
                )
            }

            if (showPenPanel) {
                PenSettingsPanel(
                    vm = vm,
                    modifier = Modifier.align(Alignment.BottomStart).padding(24.dp)
                )
            }

            if (showTreasureChest) {
                TreasureChestPanel(
                    vm = vm,
                    modifier = Modifier.align(Alignment.TopEnd).padding(24.dp)
                )
            }

            MainToolbar(
                vm = vm,
                onOpenPenPanel = { showPenPanel = !showPenPanel },
                onOpenTreasureChest = { showTreasureChest = !showTreasureChest },
                onOpenPageThumbnails = { showPageThumbnails = !showPageThumbnails },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 20.dp)
            )
        }
    }
}
