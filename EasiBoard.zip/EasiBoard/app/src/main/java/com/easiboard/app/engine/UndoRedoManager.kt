package com.easiboard.app.engine

/**
 * Command-pattern undo/redo stack. Every mutation on a [com.easiboard.app.model.Page]
 * (add stroke, erase, move object, change color, add page, delete page...) is wrapped
 * in a [Command] and pushed here instead of being applied directly, so the whole app
 * gets consistent, deep undo history for free — including cross-page operations like
 * "delete page" or "reorder pages".
 */
interface Command {
    fun apply()
    fun revert()
    /** Short label for potential "undo history" UI (EasiNote doesn't show this, but it's
     *  useful for debugging / QA and cheap to keep). */
    val label: String
}

class UndoRedoManager(private val maxHistory: Int = 200) {
    private val undoStack = ArrayDeque<Command>()
    private val redoStack = ArrayDeque<Command>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun execute(command: Command) {
        command.apply()
        undoStack.addLast(command)
        if (undoStack.size > maxHistory) undoStack.removeFirst()
        redoStack.clear() // new action invalidates the redo branch, standard editor behavior
    }

    fun undo() {
        val cmd = undoStack.removeLastOrNull() ?: return
        cmd.revert()
        redoStack.addLast(cmd)
    }

    fun redo() {
        val cmd = redoStack.removeLastOrNull() ?: return
        cmd.apply()
        undoStack.addLast(cmd)
    }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
    }
}
