package com.easiboard.app.engine

import com.easiboard.app.model.PenType
import com.easiboard.app.model.StrokePoint
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Converts a raw sequence of [StrokePoint]s into a per-point width multiplier that
 * simulates a real soft-nib pen: draw fast -> nib "lifts" -> thin line;
 * draw slow / press down -> nib "flattens" -> thick line.
 *
 * This is the single most important interactive-feel feature in the whole app, so it is
 * kept as a pure, side-effect-free class that can be unit tested independently of Compose.
 *
 * Algorithm:
 *  1. Compute instantaneous speed between consecutive points (px / ms).
 *  2. Map speed -> a target width factor via an inverse curve (faster = thinner).
 *  3. If the stylus reports real pressure, blend it in (pressure has priority over the
 *     synthetic speed estimate, since it's ground truth).
 *  4. Low-pass filter (exponential smoothing) across consecutive points so the stroke
 *     doesn't visibly "jitter" in width from tiny timestamp noise — real soft pens have
 *     physical inertia, and this smoothing reproduces that.
 */
object SoftPenPhysics {

    // Tunable per-device; these defaults feel natural on a 10-13" tablet at arm's length.
    private const val MIN_SPEED_PX_MS = 0.02f   // at/below this speed -> max thickness
    private const val MAX_SPEED_PX_MS = 3.2f    // at/above this speed -> min thickness
    private const val SMOOTHING_ALPHA = 0.35f   // 0 = no smoothing, 1 = instant (no inertia)

    /**
     * Returns one width-factor per input point (same size as [points]), already smoothed.
     * Multiply by [com.easiboard.app.model.Stroke.baseWidthDp] and clamp into
     * [minWidthFactor, maxWidthFactor] at render time.
     */
    fun computeWidthFactors(
        points: List<StrokePoint>,
        penType: PenType,
        minFactor: Float,
        maxFactor: Float
    ): FloatArray {
        val n = points.size
        val factors = FloatArray(n)
        if (n == 0) return factors

        // Pens that don't modulate width (highlighter is a flat chisel, laser has no width story).
        if (penType == PenType.HIGHLIGHTER || penType == PenType.LASER) {
            factors.fill(1f)
            return factors
        }

        var smoothed = 1f
        for (i in points.indices) {
            val speedFactor = if (i == 0) 0f else instantSpeedFactor(points[i - 1], points[i])

            // Pressure (if the stylus provides it) is authoritative; 0.5 is the "no data" default
            // reported by finger/mouse input, so only trust pressure when it deviates from that.
            val pressure = points[i].pressure
            val pressureFactor = if (pressure != 0.5f) pressure else null

            // Raw target: invert speed (fast -> thin), then blend with pressure if present.
            val speedTarget = 1f - speedFactor // 1 = slow/thick, 0 = fast/thin
            val rawTarget = pressureFactor?.let { (it * 0.7f) + (speedTarget * 0.3f) } ?: speedTarget

            // Ink brush / bamboo brush exaggerate the modulation for a more "brushy" feel.
            val exaggeration = when (penType) {
                PenType.INK_BRUSH -> 1.4f
                PenType.BAMBOO_BRUSH -> 1.2f
                PenType.SOFT_PEN -> 1.0f
                else -> 0.6f // hard brush / magic pen / texture pen stay mostly uniform
            }
            val shaped = 0.5f + (rawTarget - 0.5f) * exaggeration

            // Exponential smoothing for inertia.
            smoothed = smoothed + SMOOTHING_ALPHA * (shaped - smoothed)
            val clampedUnit = smoothed.coerceIn(0f, 1f)

            factors[i] = lerp(minFactor, maxFactor, clampedUnit)
        }
        return factors
    }

    /** 0f = fastest (thin), 1f = slowest (thick) — normalized speed between two points. */
    private fun instantSpeedFactor(a: StrokePoint, b: StrokePoint): Float {
        val dtMs = max(0.5f, (b.timestampNanos - a.timestampNanos) / 1_000_000f)
        val dist = hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble()).toFloat()
        val speed = dist / dtMs // px per ms
        val normalized = (speed - MIN_SPEED_PX_MS) / (MAX_SPEED_PX_MS - MIN_SPEED_PX_MS)
        return normalized.coerceIn(0f, 1f)
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    /**
     * When a stylus reports no pressure data at all (some cheap capacitive styluses / fingers),
     * synthesize a plausible pressure value purely from speed so downstream code can treat
     * every input source uniformly.
     */
    fun synthesizePressure(prev: StrokePoint?, current: StrokePoint): Float {
        if (prev == null) return 0.6f
        val f = instantSpeedFactor(prev, current)
        return (1f - f).coerceIn(0.15f, 1f)
    }

    fun clampWidthDp(baseWidthDp: Float, factor: Float): Float =
        (baseWidthDp * factor).coerceIn(0.5f, baseWidthDp * 3f)
}
