# EasiBoard — Interactive Whiteboard Scaffold (EasiNote/Note3-style)

A Kotlin + Jetpack Compose Android project implementing the **core engine and UI skeleton**
of a professional interactive whiteboard app, in the style of Seewo EasiNote / Note3.

## Honest scope note

A full clone of EasiNote — screen recording, PDF/PPT import & export, a complete subject-tool
library (working compass/protractor/circuit sim/periodic table), desktop annotation overlay,
cloud sync, onboarding, full settings — is a multi-month project for a small team, not something
that fits in one generated response. This scaffold implements **the hardest and most
architecturally important parts fully and correctly**, and leaves clearly-marked `TODO`
stubs (with an explanation of the intended approach) for everything else, so it's a real
foundation to keep building on rather than a mockup.

### ✅ Fully implemented
- **Infinite canvas**: pinch-zoom, two-finger pan ("roam"), world/screen coordinate transform
- **Soft pen physics** (`engine/SoftPenPhysics.kt`): stroke width dynamically follows drawing
  *speed* (fast = thin, slow = thick) and blends in real stylus *pressure* when available,
  with exponential smoothing so it feels physical, not jittery. This is the most important
  requested feature and is a standalone, unit-testable, pure-Kotlin class.
- **8 pen types** (Hard Brush, Highlighter, Ink Brush, Bamboo Brush, Soft Pen, Laser, Magic
  Pen, Texture Pen) with per-type width-modulation curves
- **Smart shape recognition** (`engine/ShapeRecognizer.kt`): freehand circle → ellipse,
  freehand quad → rectangle, freehand triangle → triangle, near-straight → line, using
  geometric feature detection (corner-angle counting + radial deviation), no ML model needed
- **Page system**: add / delete / duplicate / navigate pages, per-page background (blank,
  grid, lined, dotted, four-line English), page thumbnail sidebar
- **Undo/redo**: command-pattern stack (`engine/UndoRedoManager.kt`), used for every mutation
- **Floating, draggable, collapsible main toolbar** matching the EasiNote icon set and order
- **Rich pen settings panel**: pen type chips, thickness slider with live preview, opacity,
  42-color palette + recent colors
- **Treasure Chest** subject-tool drawer with Math/Physics/Chemistry/English widget lists,
  subject-mode switcher, and drag-to-canvas placement (the widgets currently place as inert
  objects — see roadmap for making each one interactive)
- **Spotlight** and **Screen Shade/Curtain** presentation overlays
- **Undo-safe eraser** (point mode) with locked-object protection built into the data model
- **JSON document persistence** (`engine/persistence/DocumentStore.kt`) — the `.easi`
  equivalent of `.enb` — plus a debounced `AutosaveManager`
- Material 3 theming with light/dark, English + Hindi string resources

### 🚧 Stubbed with a documented plan (see TODO comments in-file)
- `engine/recording/ScreenRecordService.kt` — MediaProjection + MediaRecorder wiring
- `engine/overlay/AnnotationOverlayService.kt` — system-overlay "draw on any app" mode
- PDF/PPT import (each page → a `Page`) and PNG/PDF/PPT export
- Per-widget interactivity for subject tools (compass that draws arcs as you rotate it,
  live-reading protractor, working simple circuit, periodic table detail popups)
- Lasso/multi-select transform handles (move/scale/rotate selection), clipboard, grouping
- Handwriting-to-text recognition for the Text tool
- Panel-in-panel (nested mini whiteboard), onboarding tutorial, settings screen

## Architecture

```
model/          Pure data classes (Stroke, Page, Document, Tool, PenSettings...) — all
                @Serializable, zero Android/Compose dependencies, easy to unit test
engine/         Business logic: SoftPenPhysics, ShapeRecognizer, UndoRedoManager,
                persistence, and (stubbed) recording/overlay services
viewmodel/      WhiteboardViewModel — single source of truth for the screen; all
                mutation flows through UndoRedoManager so history is never bypassed
ui/             Compose screens & components. WhiteboardCanvas.kt is the drawing surface;
                MainToolbar / PenSettingsPanel / TreasureChestPanel / PageThumbnailBar /
                PresentationOverlays are the floating UI pieces composed in WhiteboardScreen.kt
```

Data flows one way: gesture → `ViewModel` method → `UndoRedoManager.execute(Command)` →
mutates `Document` + the observable Compose state lists → canvas recomposes and redraws.

## Opening the project

1. Android Studio Koala (2024.1) or newer.
2. Open the `EasiBoard/` folder directly (it's a standard Gradle multi-module layout:
   root `settings.gradle.kts` + `app/build.gradle.kts`).
3. Let Gradle sync (needs network access to Google/Maven Central for the Compose BOM,
   kotlinx-serialization, kotlinx-collections-immutable).
4. Run on a tablet emulator or device with API 26+. A stylus-enabled emulator (or a real
   Samsung/Xiaomi tablet with S-Pen/stylus) is needed to see pressure-based width blending —
   on a finger-only device the soft pen still works from *speed* alone.

## Suggested build order for the remaining features

1. Multi-select transform (move/scale/rotate) — reuses the existing `Bounds` hit-testing
2. PDF import (render each page to a background image via `PdfRenderer`) — unlocks a huge
   chunk of real classroom usage (annotating over slides/worksheets)
3. Interactive Math widgets (compass + protractor) — highest subject-tool value per effort
4. Screen recording — self-contained, doesn't touch the rest of the app
5. Desktop/Annotation overlay mode — needs careful permission UX (`SYSTEM_ALERT_WINDOW`)
